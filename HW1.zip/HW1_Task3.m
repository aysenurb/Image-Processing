%Aysenur Buyukbal 170316007 
img = imread('coloredChips.png');
gray = rgb2gray(img);
bw_img = im2bw(img);
hist=imhist(gray);

colormap gray

subplot(221);
imagesc(img);
title('RGB');

subplot(222);
imagesc(gray);
title('Grayscale');

subplot(223);
imagesc(bw_img);
title('BW Image');

subplot(224);
imhist(gray);
title('Histogram');