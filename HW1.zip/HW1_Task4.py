from PIL import Image,ImageFilter
import os

#AYSENUR BUYUKBAL 170316007

size_300= (300,300)
size_700= (700,700)

img= Image.open('sample6.jpg')
img.show()
img.save('sample6.png')
#OPEN-DISPLAY-SAVE DIFFERENT FORMAT

for f in os.listdir('.'):
    if f.endswith('.jpg'):
        i=Image.open(f)
        fn,fext = os.path.splitext(f)
        i.thumbnail(size_300)
        i.save('300/{}_300{}'.format(fn,fext))
#RESIZING AND SAVING THEM TO ANOTHER DIRECTORY
        i.thumbnail(size_700)
        i.save('700/{}_700{}'.format(fn,fext))
#CHANGING THE SIZE TO 700 AND SAVING THEM TO NEW DIRECTORY

img= Image.open('sample6.jpg')
img.rotate(90).save('sample6_mod.jpg')
#ROTATING WITH 90 DEGREE AND SAVING

img= Image.open('sample6.jpg')
img.convert(mode='L').save('sample6_BW.jpg')
#FILTERED BLACK-WHITE

img= Image.open('sample6.jpg')
img.filter(ImageFilter.GaussianBlur(15)).save('sample6_Blurred.jpg')
#FILTERED GAUSSIAN BLUR WITH VALUE 15

img= Image.open('sample6.jpg')
img.filter(ImageFilter.CONTOUR()).save('sample6_Contour.jpg')
#FILTERED CONTOUR